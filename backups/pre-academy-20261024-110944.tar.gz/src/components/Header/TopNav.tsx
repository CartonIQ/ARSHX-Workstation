import React, { useRef } from 'react';
import { 
  FolderGit2, 
  Code2, 
  Terminal, 
  Sparkles, 
  Globe, 
  Gamepad2, 
  GraduationCap, 
  Wrench, 
  Smartphone, 
  Monitor, 
  Download,
  Upload,
  Settings
} from 'lucide-react';
import { ActiveTab, Project } from '../../types';
import { ArshxLogo } from '../Brand/ArshxLogo';

interface TopNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  activeProject: Project;
  mobileFrameMode: boolean;
  onToggleMobileFrame: () => void;
  onExportZip: () => void;
  onSaveZip: () => void;
  onImportZip?: (file: File) => void;
  onOpenAi: () => void;
  onOpenSettings: () => void;
  aiAvailable: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  onTabChange,
  activeProject,
  mobileFrameMode,
  onToggleMobileFrame,
  onExportZip,
  onSaveZip,
  onImportZip,
  onOpenAi,
  onOpenSettings,
  aiAvailable,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onImportZip) {
      onImportZip(file);
    }
    if (e.target) e.target.value = '';
  };

  return (
    <header className="app-header glass-panel border-x-0 border-t-0 rounded-none sm:px-5 flex items-center justify-between gap-4 shrink-0 z-30 select-none">
      {/* Hidden ZIP input for quick import from anywhere */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".zip"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Zone 1: Brand Wordmark with Precision Logo */}
      <div 
        onClick={() => onTabChange('home')} 
        className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity shrink-0"
      >
        <ArshxLogo size="sm" />
        <div className="flex flex-col">
          <div className="flex items-center gap-1 leading-none">
            <span className="text-base font-black tracking-wider text-[#F7F7FA]">
              ARSHX
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#E5222A]" />
          </div>
          <span className="text-[9px] font-bold text-[#E5222A] tracking-widest mt-0.5 leading-none">
            WORKSTATION
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden xl:flex items-center gap-1">
        <button
          onClick={() => onTabChange('home')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'home'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <FolderGit2 className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>Workspace</span>
        </button>

        <button
          onClick={() => onTabChange('creator')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'creator'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-[#FBBF24]" />
          <span>AI Creator</span>
        </button>

        <button
          onClick={() => onTabChange('editor')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'editor'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Code2 className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>Editor</span>
        </button>

        <button
          onClick={() => onTabChange('terminal')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'terminal'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>Terminal</span>
        </button>

        <button
          onClick={() => onTabChange('website')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'website'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-[#67E8F9]" />
          <span>Web Studio</span>
        </button>



        <button
          onClick={() => onTabChange('doctor')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'doctor' || activeTab === 'build'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Wrench className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>Tools</span>
        </button>

        <button
          onClick={() => onTabChange('toolkit')}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'toolkit'
              ? 'bg-[#24242C] text-white'
              : 'text-[#A5A5B2] hover:text-[#F7F7FA] hover:bg-[#1A1A20]'
          }`}
        >
          <Wrench className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>Toolkit</span>
        </button>
      </nav>

      {/* Zone 3: Actions & Phone Frame Toggle */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenSettings}
          className="p-2 bg-[#1A1A20] hover:bg-[#24242C] text-[#A5A5B2] hover:text-white rounded-lg border border-[#2B2B38] transition-colors"
          title="Settings & Privacy"
        >
          <Settings className="w-4 h-4" />
        </button>

        <button
          onClick={onToggleMobileFrame}
          title={mobileFrameMode ? "Desktop workstation mode" : "Mobile phone frame mode"}
          className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
            mobileFrameMode
              ? 'bg-[#E5222A]/15 text-[#FF5E65] border-[#E5222A]/40'
              : 'bg-[#1A1A20] text-[#A5A5B2] border-[#2B2B38] hover:text-white'
          }`}
        >
          {mobileFrameMode ? (
            <>
              <Smartphone className="w-3.5 h-3.5 text-[#E5222A]" />
              <span className="hidden sm:inline">Phone Frame</span>
            </>
          ) : (
            <>
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Desktop</span>
            </>
          )}
        </button>

        <button
          onClick={onOpenAi}
          className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#24242C] text-[#F7F7FA] border border-[#34343E] hover:border-[#E5222A]/50 hover:bg-[#2B2B36] transition-all flex items-center gap-1.5 whitespace-nowrap"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#E5222A]" />
          <span>AI Engineer</span>
        </button>

        {onImportZip && (
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-1.5 text-xs font-semibold text-[#F7F7FA] bg-[#1F1F27] hover:bg-[#282834] rounded-lg border border-[#2E2E3C] transition-all flex items-center gap-1.5 whitespace-nowrap"
            title="Import Project Archive (.ZIP)"
          >
            <Upload className="w-3.5 h-3.5 text-[#67E8F9]" />
            <span className="hidden md:inline">Import ZIP</span>
          </button>
        )}

<button
  onClick={onSaveZip}
  className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#292929] rounded-lg hover:bg-[#3b3b3b] active:scale-95 transition-all flex items-center gap-1.5 whitespace-nowrap"
  title="Save the project ZIP to a chosen folder"
>
  <Download className="w-3.5 h-3.5" />
  <span>Save ZIP</span>
</button>
        <button
          onClick={onExportZip}
          className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#E5222A] rounded-lg hover:bg-[#d01c24] active:scale-95 transition-all flex items-center gap-1.5 whitespace-nowrap shadow-sm shadow-[#E5222A]/30"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export ZIP</span>
        </button>
      </div>
    </header>
  );
};
