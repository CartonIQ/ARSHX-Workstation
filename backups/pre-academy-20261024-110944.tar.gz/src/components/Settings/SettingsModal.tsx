import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  X, 
  HardDrive, 
  ShieldCheck, 
  Sliders, 
  Sparkles, 
  Download, 
  Upload, 
  Info,
  Check,
  KeyRound,
  Eye,
  EyeOff,
  Loader2
} from 'lucide-react';
import { EditorSettings, Project } from '../../types';
import { ArshxLogo } from '../Brand/ArshxLogo';
import { OWNER } from '../../data/owner';
import {
  getApiKey,
  setApiKey,
  getModel,
  setModel,
  looksLikeApiKey,
  testApiKey,
  MODEL_CHOICES,
} from '../../utils/gemini';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  editorSettings: EditorSettings;
  onUpdateEditorSettings: (settings: EditorSettings) => void;
  projects: Project[];
  onImportBackup: (projects: Project[]) => void;
  onReplaySplash?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  editorSettings,
  onUpdateEditorSettings,
  projects,
  onImportBackup,
  onReplaySplash,
}) => {
  const [activeCategory, setActiveCategory] = useState<'editor' | 'ai' | 'privacy' | 'storage' | 'about'>('editor');
  const [keyInput, setKeyInput] = useState('');
  const [modelInput, setModelInput] = useState(getModel());
  const [showKey, setShowKey] = useState(false);
  const [keyStatus, setKeyStatus] = useState<{ kind: 'idle' | 'testing' | 'ok' | 'error'; msg?: string }>({ kind: 'idle' });
  const [hasSavedKey, setHasSavedKey] = useState(() => getApiKey().length > 0);

  useEffect(() => {
    if (isOpen) {
      setKeyInput('');
      setShowKey(false);
      setKeyStatus({ kind: 'idle' });
      setModelInput(getModel());
      setHasSavedKey(getApiKey().length > 0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveKey = async () => {
    const candidate = keyInput.trim();
    if (!looksLikeApiKey(candidate)) {
      setKeyStatus({ kind: 'error', msg: 'That does not look like a Gemini API key. Keys are 20+ letters, digits, - or _.' });
      return;
    }
    setKeyStatus({ kind: 'testing' });
    try {
      await testApiKey(candidate, modelInput);
      setApiKey(candidate);
      setModel(modelInput);
      setHasSavedKey(true);
      setKeyInput('');
      setKeyStatus({ kind: 'ok', msg: 'Key verified and saved on this device.' });
    } catch (err: any) {
      setKeyStatus({ kind: 'error', msg: err?.message || 'Could not verify the key.' });
    }
  };

  const handleRemoveKey = () => {
    setApiKey('');
    setHasSavedKey(false);
    setKeyInput('');
    setKeyStatus({ kind: 'ok', msg: 'Key removed from this device.' });
  };

  // Calculate local storage size
  const storageBytes = new Blob([JSON.stringify(projects)]).size;
  const storageKb = (storageBytes / 1024).toFixed(1);

  const handleExportBackup = () => {
    const dataStr = JSON.stringify(projects, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `arshx_workspace_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed) && parsed.length > 0) {
          onImportBackup(parsed);
          alert(`Successfully restored ${parsed.length} projects!`);
          onClose();
        }
      } catch (err) {
        alert('Invalid backup JSON file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      <div className="glass-panel w-full max-w-2xl rounded-3xl overflow-hidden flex flex-col max-h-[88dvh]">
        {/* Modal Header */}
        <div className="h-14 bg-[#181820] border-b border-[#262633] px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#E5222A]" />
            <h3 className="text-base font-bold text-white">ARSHX Workstation Settings</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-2 hover:bg-[#24242C] rounded-lg text-[#A5A5B2] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
          {/* Categories Sidebar */}
          <div className="w-full sm:w-48 bg-[#111114] border-b sm:border-b-0 sm:border-r border-[#24242C] p-2 flex sm:block gap-1 sm:space-y-1 overflow-x-auto sm:overflow-visible shrink-0">
            {[
              { id: 'editor', label: 'Editor Preferences', icon: Sliders },
              { id: 'ai', label: 'AI (Gemini)', icon: KeyRound },
              { id: 'privacy', label: 'Privacy & Security', icon: ShieldCheck },
              { id: 'storage', label: 'Storage & Backup', icon: HardDrive },
              { id: 'about', label: 'About ARSHX', icon: Info },
            ].map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id as any)}
                  className={`w-auto sm:w-full whitespace-nowrap min-h-[40px] px-3 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 text-left transition-colors shrink-0 ${
                    activeCategory === cat.id
                      ? 'bg-[#24242C] text-white shadow-xs'
                      : 'text-[#A5A5B2] hover:text-white hover:bg-[#181820]'
                  }`}
                >
                  <Icon className="w-4 h-4 text-[#E5222A]" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Details Content */}
          <div className="flex-1 p-6 overflow-y-auto space-y-5 text-xs text-[#CBD5E1]">
            {activeCategory === 'editor' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white mb-2">Code Editor Configuration</h4>
                
                <div className="flex items-center justify-between py-2 border-b border-[#24242E]">
                  <div>
                    <span className="font-semibold text-white block">Font Size</span>
                    <span className="text-[11px] text-[#A5A5B2]">Editor font size in pixels</span>
                  </div>
                  <select
                    value={editorSettings.fontSize}
                    onChange={(e) => onUpdateEditorSettings({ ...editorSettings, fontSize: Number(e.target.value) })}
                    className="bg-[#1C1C24] border border-[#2E2E38] rounded-lg px-2.5 py-1 text-white text-xs font-mono"
                  >
                    {[12, 13, 14, 15, 16, 18].map(s => (
                      <option key={s} value={s}>{s}px</option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between py-2 border-b border-[#24242E]">
                  <div>
                    <span className="font-semibold text-white block">Tab Size</span>
                    <span className="text-[11px] text-[#A5A5B2]">Spaces inserted by the Tab / CodeKeys key</span>
                  </div>
                  <select
                    value={editorSettings.tabSize}
                    onChange={(e) => onUpdateEditorSettings({ ...editorSettings, tabSize: Number(e.target.value) })}
                    className="bg-[#1C1C24] border border-[#2E2E38] rounded-lg px-2.5 py-1 text-white text-xs font-mono"
                  >
                    <option value={2}>2 spaces</option>
                    <option value={4}>4 spaces</option>
                  </select>
                </div>

                <div className="flex items-center justify-between py-2 border-b border-[#24242E]">
                  <div>
                    <span className="font-semibold text-white block">Word Wrap</span>
                    <span className="text-[11px] text-[#A5A5B2]">Wrap long lines inside the editor viewport</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={editorSettings.wordWrap}
                    onChange={(e) => onUpdateEditorSettings({ ...editorSettings, wordWrap: e.target.checked })}
                    className="accent-[#E5222A]"
                  />
                </div>

                <div className="flex items-center justify-between py-2 border-b border-[#24242E]">
                  <div>
                    <span className="font-semibold text-white block">Auto-Save</span>
                    <span className="text-[11px] text-[#A5A5B2]">Persist buffer modifications automatically</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={editorSettings.autoSave}
                    onChange={(e) => onUpdateEditorSettings({ ...editorSettings, autoSave: e.target.checked })}
                    className="accent-[#E5222A]"
                  />
                </div>
              </div>
            )}

            {activeCategory === 'ai' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white mb-2">Gemini API Key</h4>
                <div className="glass-card p-4 space-y-3 leading-relaxed">
                  <p>
                    AI features use <strong>your own</strong> Google Gemini key. It is stored only in this app's
                    private storage on this device and is sent only to Google's Gemini API.
                    Create a key at <span className="font-mono text-white">aistudio.google.com/apikey</span>.
                  </p>
                  <div className="flex items-center gap-2 text-[11px]">
                    <span className={`inline-block w-2 h-2 rounded-full ${hasSavedKey ? 'bg-[#22C55E]' : 'bg-[#85858F]'}`} />
                    <span className="text-white font-semibold">{hasSavedKey ? 'A key is saved on this device' : 'No key saved'}</span>
                  </div>

                  <label className="block">
                    <span className="font-semibold text-white block mb-1">{hasSavedKey ? 'Replace key' : 'API key'}</span>
                    <div className="relative">
                      <input
                        type={showKey ? 'text' : 'password'}
                        value={keyInput}
                        onChange={(e) => { setKeyInput(e.target.value); setKeyStatus({ kind: 'idle' }); }}
                        placeholder="AIza..."
                        autoComplete="off"
                        autoCapitalize="off"
                        autoCorrect="off"
                        spellCheck={false}
                        className="glass-input w-full pr-10 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowKey(!showKey)}
                        aria-label={showKey ? 'Hide key' : 'Show key'}
                        className="absolute right-1 top-1/2 -translate-y-1/2 p-2 text-[#A5A5B2] hover:text-white"
                      >
                        {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </label>

                  <label className="block">
                    <span className="font-semibold text-white block mb-1">Model</span>
                    <select
                      value={modelInput}
                      onChange={(e) => setModelInput(e.target.value)}
                      className="glass-input w-full font-mono"
                    >
                      {[...new Set([modelInput, ...MODEL_CHOICES])].map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </label>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      onClick={handleSaveKey}
                      disabled={keyStatus.kind === 'testing' || !keyInput.trim()}
                      className="btn-primary"
                    >
                      {keyStatus.kind === 'testing' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                      <span>{keyStatus.kind === 'testing' ? 'Verifying...' : 'Verify & Save'}</span>
                    </button>
                    {hasSavedKey && (
                      <button onClick={handleRemoveKey} className="btn-ghost">Remove key</button>
                    )}
                    {hasSavedKey && modelInput !== getModel() && !keyInput.trim() && (
                      <button onClick={() => { setModel(modelInput); setKeyStatus({ kind: 'ok', msg: 'Model updated.' }); }} className="btn-ghost">Save model</button>
                    )}
                  </div>

                  {keyStatus.kind !== 'idle' && keyStatus.kind !== 'testing' && (
                    <p role="status" className={`text-[11px] font-semibold ${keyStatus.kind === 'ok' ? 'text-[#86EFAC]' : 'text-[#FF5E65]'}`}>
                      {keyStatus.msg}
                    </p>
                  )}
                </div>
              </div>
            )}

            {activeCategory === 'privacy' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white mb-2">Privacy & Security Policies</h4>
                <div className="p-4 bg-[#1A1A22] border border-[#2B2B38] rounded-xl space-y-2 leading-relaxed">
                  <p>
                    <strong>Local Data & Storage:</strong> ARSHX stores project data and editor information in the app's browser storage on this device. Data stored locally may still be accessible to someone with access to your device or app data. Clearing app data, uninstalling the app, or storage failures may result in data loss. Export important projects regularly and keep backups in a secure location.
                  </p>
                  <p>
                    <strong>AI & Third-Party Data Sharing:</strong> When you use AI features, the prompts and project or file context required for the request may be sent to Google's Gemini API using the API key configured in Settings. Avoid including passwords, private keys, personal information, or confidential code in AI prompts. Google's processing and retention of submitted data are governed by Google's applicable terms and privacy policies. Network requests and third-party services may process technical information needed to provide their services.
                  </p>
                  <p>
                    <strong>API Key & Security:</strong> Your Gemini API key is stored by the app for AI requests. Do not share your key or include it in code, screenshots, logs, or public repositories. Anyone who obtains your key may be able to use it subject to your Google account's permissions and limits. Use Google's key-management controls to restrict, monitor, or revoke a key if necessary. Local storage is not a guarantee of encrypted secret storage.
                  </p>
                  <p>
                    <strong>Telemetry & Network Activity:</strong> ARSHX's privacy claims should reflect the app's actual network behavior. AI requests and any enabled preview, external-resource, or third-party integrations may generate network traffic. This notice is not a guarantee that every component or dependency makes no network requests. Review app permissions and network behavior if you require stricter privacy.
                  </p>
                  <p>
                    <strong>Ownership & User Responsibility:</strong> You remain responsible for the projects and content you create, import, export, or submit to third-party services. Ensure you have permission to use any third-party code or assets, and review applicable licenses and service terms. Keep independent backups of important work.
                  </p>
                  <p>
                    <strong>Security Limitations:</strong> ARSHX cannot guarantee absolute security, uninterrupted availability, or recovery of lost data. Keep your device and app updated, protect device access, and avoid storing sensitive credentials in project files. Report suspected security issues through the project's official support channel.
                  </p>
                </div>
              </div>
            )}

            {activeCategory === 'storage' && (
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white mb-2">Storage Usage & Data Portability</h4>

                <div className="bg-[#181820] border border-[#262633] p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-xs text-[#A5A5B2] block">Local Storage Footprint</span>
                    <span className="text-xl font-bold font-mono text-white">{storageKb} KB</span>
                  </div>
                  <span className="text-xs font-mono text-[#86EFAC] bg-[#22C55E]/10 border border-[#22C55E]/20 px-2.5 py-1 rounded-lg">
                    {projects.length} Projects Saved
                  </span>
                </div>

                <div className="space-y-2 pt-2">
                  <span className="font-bold text-white block">Workspace Backup / Restore</span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={handleExportBackup}
                      className="px-4 py-2 bg-[#24242C] hover:bg-[#2C2C36] text-white rounded-lg font-semibold flex items-center gap-1.5 border border-[#34343E]"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export Backup (JSON)</span>
                    </button>

                    <label className="px-4 py-2 bg-[#E5222A] hover:bg-[#d01c24] text-white rounded-lg font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-[#E5222A]/20">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Restore from File</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleImportFile}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {activeCategory === 'about' && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 pb-3 border-b border-[#24242C]">
                  <ArshxLogo size="md" />
                  <div>
                    <h4 className="text-base font-black tracking-wide text-white">ARSHX Workstation</h4>
                    <p className="text-[11px] text-[#E5222A] font-bold tracking-widest uppercase">BUILD. CREATE. RISE.</p>
                    <p className="text-[10px] text-[#85858F] font-mono mt-0.5">Your code. Your vision. Your universe.</p>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-[#A5A5B2] leading-relaxed font-mono bg-[#111114] p-3 rounded-xl border border-[#24242C]">
                  <p><strong className="text-white">Version:</strong> {__APP_VERSION__}</p>
                  <p><strong className="text-white">App ID:</strong> com.arshx.workstation</p>
                  <p><strong className="text-white">Runtime:</strong> React 19 in a Capacitor Android WebView</p>
                  <p><strong className="text-white">Target SDK:</strong> 35 (Android 15)</p>
                  <p><strong className="text-white">Primary Red:</strong> #E5222A · <strong className="text-white">Obsidian:</strong> #111114</p>
                </div>

                <section aria-labelledby="owner-heading" className="glass-card p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl btn-primary !p-0 !min-h-0 text-base font-black shrink-0" aria-hidden="true">
                      {OWNER.name.split(' ').map((w) => w[0]).join('').slice(0, 2)}
                    </div>
                    <div className="min-w-0">
                      <h4 id="owner-heading" className="text-sm font-extrabold text-white leading-tight">{OWNER.name}</h4>
                      <p className="text-[11px] text-[#FF5E65] font-semibold">{OWNER.role} · {OWNER.brand}</p>
                    </div>
                  </div>
                  <div className="space-y-2 text-xs text-[#D4D4DE] leading-relaxed">
                    {OWNER.bio.map((p, i) => <p key={i}>{p}</p>)}
                  </div>
                  <ul className="space-y-1.5 pt-1">
                    {OWNER.links.map((l) => (
                      <li key={l.label} className="flex items-center justify-between gap-3 text-xs min-h-[32px]">
                        <span className="text-[#9494A6] font-semibold shrink-0">{l.label}</span>
                        {l.href ? (
                          <a href={l.href} target="_blank" rel="noopener noreferrer" className="text-[#FF8A90] font-semibold underline underline-offset-2 truncate">{l.value}</a>
                        ) : (
                          <span className="text-white font-semibold truncate">{l.value}</span>
                        )}
                      </li>
                    ))}
                  </ul>
                </section>

                {onReplaySplash && (
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        onClose();
                        onReplaySplash();
                      }}
                      className="px-4 py-2 bg-[#1C1C24] hover:bg-[#252530] text-white rounded-lg text-xs font-semibold border border-[#34343E] transition-colors flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#E5222A]" />
                      <span>Play Brand Splash Screen</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
